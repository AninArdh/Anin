/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Good Day
 */
public class Order {
    private List<MenuItem> items;
    private Promotion promotion;

    public Order() {
        items = new ArrayList<>();
    }

    public void addItem(MenuItem item) {
        items.add(item);
    }

    public void setPromotion(Promotion promotion) {
        this.promotion = promotion;
    }

    public int getTotalPrice() {
        int totalPrice = 0;
        for (MenuItem item : items) {
            totalPrice += item.getPrice();
        }
        if (promotion != null) {
            int discount = (totalPrice * promotion.getDiscount()) / 100;
            totalPrice -= discount;
        }
        return totalPrice;
    }

    public List<MenuItem> getItems() {
        return items;
    }
}

