/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Good Day
 */
public class HappyHourPromotion implements Promotion {
    private int discount;

    public HappyHourPromotion(int discount) {
        this.discount = discount;
    }

    @Override
    public int getDiscount() {
        return discount;
    }
}

