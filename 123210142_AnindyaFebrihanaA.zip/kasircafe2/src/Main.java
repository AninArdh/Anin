/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Good Day
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Order order = new Order();
        boolean isDone = false;

        while (!isDone) {
            System.out.println("Menu:");
            System.out.println("1. Minuman");
            System.out.println("2. Makanan");
            System.out.println("3. Check out");
            System.out.print("Masukkan Pilihan : ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Minuman :");
                    System.out.println("1. Americano Coffee (Rp. 10000)");
                    System.out.println("2. Lecyhee Tea (Rp. 8000)");
                    System.out.print("Masukkan Pilihan : ");
                    int drinkChoice = scanner.nextInt();
                    scanner.nextLine();

                    switch (drinkChoice) {
                        case 1:
                            Drink coffee = new Drink("Americano Coffee", 15000, "Regular");
                            order.addItem(coffee);
                            break;
                        case 2:
                            Drink tea = new Drink("Lecyhee Tea", 23000, "Regular");
                            order.addItem(tea);
                            break;
                        default:
                            System.out.println("Pilihan Tidak Ada!");
                            break;
                    }
                    break;
                case 2:
                    System.out.println("Makanan:");
                    System.out.println("1. Mie Goreng (Rp. 15000)");
                    System.out.println("2. Nasi Sambal Matah (Rp. 20000)");
                    System.out.println("3. Kentang Goreng (Rp. 10000)");
                    System.out.print("Masukkan Pilihan : ");
                    int foodChoice = scanner.nextInt();
                    scanner.nextLine();

                    switch (foodChoice) {
                        case 1:
                            Food friedRice = new Food("Mie Goreng", 15000, false);
                            order.addItem(friedRice);
                            break;
                        case 2:
                            Food friedNoodle = new Food("Nasi Sambal Matah", 12000, true);
                            order.addItem(friedNoodle);
                            break;
                        case 3:
                            Food friedTofu = new Food("Kentang Goreng", 10000, false);
                            order.addItem(friedTofu);
                            break;
                        default:
                            System.out.println("Pilihan Tidak Ada!");
                            break;
                    }
                    break;
                case 3:
                    isDone = true;
                    break;
                default:
                    System.out.println("Pilihan Tidak Ada!");
                    break;
            }
        }

        System.out.println("Apakah kamu mempunyai kode promosi? (y/n)");
        String promotionChoice = scanner.nextLine();

        if (promotionChoice.equalsIgnoreCase("y")) {
            System.out.print("Masukkan Kode Promosi : ");
            String code = scanner.nextLine();
            if (code.equalsIgnoreCase("HOMEBREWER")) {
                order.setPromotion(new HappyHourPromotion(20));
            } else {
                System.out.println("Kode Promosi Salah!");
            }
        }

        System.out.println("Detail Pesanan :");
        for (MenuItem item : order.getItems()) {
            System.out.println("- " + item);
        }
        System.out.println("Total Belanja : Rp. " + order.getTotalPrice());

        scanner.close();
    }
}

