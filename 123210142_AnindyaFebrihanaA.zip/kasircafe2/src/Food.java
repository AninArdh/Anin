/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Good Day
 */
public class Food extends MenuItem {
    protected boolean isVegetarian;

    public Food(String name, int price, boolean isVegetarian) {
        super(name, price);
        this.isVegetarian = isVegetarian;
    }

    public boolean isVegetarian() {
        return isVegetarian;
    }

    @Override
    public String getCategory() {
        return "Makanan";
    }

    @Override
    public String toString() {
        String vegetarian = isVegetarian ? " (Vegetarian)" : "";
        return name + vegetarian + " - Rp. " + price;
    }
}

