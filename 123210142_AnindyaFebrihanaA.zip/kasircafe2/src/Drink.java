/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Good Day
 */
public class Drink extends MenuItem {
    protected String size;

    public Drink(String name, int price, String size) {
        super(name, price);
        this.size = size;
    }

    public String getSize() {
        return size;
    }

    @Override
    public String getCategory() {
        return "Minuman";
    }

    @Override
    public String toString() {
        return size + " " + name + " - Rp. " + price;
    }
}
